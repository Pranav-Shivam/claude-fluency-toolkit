#!/usr/bin/env bash
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)/today-brief"
DEST="$HOME/.claude/skills/today-brief"

mkdir -p "$HOME/.claude/skills"
rm -rf "$DEST"
cp -r "$SRC" "$DEST"
chmod +x "$DEST/scripts/context.sh"

echo "Installed to $DEST"
echo "Open Claude Code and run: /today-brief"
echo "Output goes to ${TODAY_BRIEF_DIR:-$HOME/today-brief}/YYYY-MM-DD/"
