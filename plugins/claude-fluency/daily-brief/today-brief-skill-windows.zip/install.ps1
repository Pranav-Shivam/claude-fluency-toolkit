# Installs the /today-brief skill for the current Windows user.
# Run:  powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
$src  = Join-Path $PSScriptRoot 'today-brief'
$dest = Join-Path $env:USERPROFILE '.claude\skills\today-brief'

New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
Copy-Item -Recurse -Path $src -Destination $dest

Write-Host "Installed to $dest"
Write-Host "Open Claude Code and run: /today-brief"
$out = if ($env:TODAY_BRIEF_DIR) { $env:TODAY_BRIEF_DIR } else { Join-Path $env:USERPROFILE 'today-brief' }
Write-Host "Output goes to $out\YYYY-MM-DD\"
Write-Host ""
Write-Host "If /today-brief reports the PowerShell tool is unavailable, add this to $env:USERPROFILE\.claude\settings.json and restart Claude Code:"
Write-Host '  { "env": { "CLAUDE_CODE_USE_POWERSHELL_TOOL": "1" } }'
