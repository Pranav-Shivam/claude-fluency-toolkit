"""
Synthetic RFQ demo data generator.
Produces:
  emails/email_00X.json      - inbox messages (some with attachments, some pure-text RFQs, some noise/non-RFQ)
  attachments/*.txt          - itemized RFQ line-sheets referenced by some emails
  pricing_catalog.json       - product catalog with unit price / lead time / stock, used to price quotes
  customers.json             - customer/account master data (for matching sender -> account, terms, discount tier)
  README.md                  - describes the dataset and the intended agent workflow

This is entirely synthetic (no real names/domains/PII) - built for a Claude Code agent demo:
  inbox -> classify (RFQ vs not) -> extract line items -> price against catalog -> apply customer terms -> draft quote
"""
import json
import os

BASE = "/home/claude/rfq_demo"

# ---------------------------------------------------------------------------
# 1. Product / pricing catalog
# ---------------------------------------------------------------------------
catalog = {
    "currency": "USD",
    "updated": "2026-08-01",
    "products": [
        {"sku": "GL-CLR-6MM", "name": "Clear Float Glass 6mm", "unit": "sq_ft", "unit_price": 8.75, "lead_time_days": 5, "stock_qty": 12000},
        {"sku": "GL-TMP-8MM", "name": "Tempered Glass 8mm", "unit": "sq_ft", "unit_price": 14.20, "lead_time_days": 10, "stock_qty": 4200},
        {"sku": "GL-LAM-10MM", "name": "Laminated Safety Glass 10mm", "unit": "sq_ft", "unit_price": 19.95, "lead_time_days": 14, "stock_qty": 2100},
        {"sku": "AL-FRM-STD", "name": "Standard Aluminum Frame Extrusion", "unit": "linear_ft", "unit_price": 6.40, "lead_time_days": 7, "stock_qty": 30000},
        {"sku": "AL-FRM-TH", "name": "Thermally Broken Aluminum Frame", "unit": "linear_ft", "unit_price": 11.10, "lead_time_days": 12, "stock_qty": 9000},
        {"sku": "SEAL-STRUC", "name": "Structural Silicone Sealant", "unit": "cartridge", "unit_price": 22.50, "lead_time_days": 3, "stock_qty": 1500},
        {"sku": "GSK-EPDM", "name": "EPDM Gasket Strip", "unit": "linear_ft", "unit_price": 1.85, "lead_time_days": 4, "stock_qty": 50000},
        {"sku": "HW-HNG-HD", "name": "Heavy Duty Hinge Set", "unit": "each", "unit_price": 34.00, "lead_time_days": 6, "stock_qty": 800},
        {"sku": "GL-LOWE-6MM", "name": "Low-E Coated Glass 6mm", "unit": "sq_ft", "unit_price": 12.60, "lead_time_days": 9, "stock_qty": 6000},
        {"sku": "AL-FRM-CUST", "name": "Custom Anodized Frame Extrusion", "unit": "linear_ft", "unit_price": 15.75, "lead_time_days": 21, "stock_qty": 1200},
    ],
}

with open(f"{BASE}/pricing_catalog.json", "w") as f:
    json.dump(catalog, f, indent=2)

# ---------------------------------------------------------------------------
# 2. Customer master data
# ---------------------------------------------------------------------------
customers = {
    "customers": [
        {"account_id": "ACC-1001", "company": "Meridian Glazing Contractors", "domain": "meridianglazing.example", "tier": "Gold", "discount_pct": 8, "payment_terms": "Net 30", "region": "West"},
        {"account_id": "ACC-1002", "company": "Union Curtainwall Systems", "domain": "unioncurtainwall.example", "tier": "Silver", "discount_pct": 4, "payment_terms": "Net 30", "region": "Midwest"},
        {"account_id": "ACC-1003", "company": "Harborline Facade Co.", "domain": "harborlinefacade.example", "tier": "Platinum", "discount_pct": 12, "payment_terms": "Net 45", "region": "East"},
        {"account_id": "ACC-1004", "company": "Prairie Window & Door", "domain": "prairiewd.example", "tier": "Bronze", "discount_pct": 0, "payment_terms": "Net 15", "region": "Midwest"},
        {"account_id": "ACC-1005", "company": "Coastal Envelope Solutions", "domain": "coastalenvelope.example", "tier": "Gold", "discount_pct": 8, "payment_terms": "Net 30", "region": "South"},
    ]
}

with open(f"{BASE}/customers.json", "w") as f:
    json.dump(customers, f, indent=2)

# ---------------------------------------------------------------------------
# 3. Inbox emails (mix of clean RFQs, RFQs with attachments, ambiguous, and noise)
# ---------------------------------------------------------------------------

emails = [
    {
        "id": "email_001",
        "from": "procurement@meridianglazing.example",
        "to": "quotes@obe-sales.example",
        "subject": "RFQ - Clear glass + standard frame for Riverside project",
        "date": "2026-08-03T09:14:00-05:00",
        "body": (
            "Hi team,\n\n"
            "We need a quote for the Riverside Tower glazing package:\n"
            "- Clear Float Glass 6mm: 4,200 sq ft\n"
            "- Standard Aluminum Frame Extrusion: 1,800 linear ft\n"
            "- EPDM Gasket Strip: 1,800 linear ft\n\n"
            "Need this priced by end of week, project starts in 3 weeks so lead time matters.\n\n"
            "Thanks,\nDana Whitfield\nMeridian Glazing Contractors"
        ),
        "attachments": [],
        "label": "rfq_inline",
    },
    {
        "id": "email_002",
        "from": "buyer@unioncurtainwall.example",
        "to": "quotes@obe-sales.example",
        "subject": "Quote request - see attached line sheet",
        "date": "2026-08-03T11:02:00-05:00",
        "body": (
            "Please find our itemized requirements attached for the Lakeside Commons curtainwall bid. "
            "Let us know pricing and lead times. We're comparing two suppliers so turnaround matters.\n\n"
            "Regards,\nTom Reyes"
        ),
        "attachments": ["email_002_linesheet.txt"],
        "label": "rfq_attachment",
    },
    {
        "id": "email_003",
        "from": "estimating@harborlinefacade.example",
        "to": "quotes@obe-sales.example",
        "subject": "RFQ: Custom anodized frame + laminated glass - Pier 14 Redevelopment",
        "date": "2026-08-04T08:45:00-04:00",
        "body": (
            "Good morning,\n\n"
            "Requesting pricing for Pier 14 Redevelopment, phase 1:\n"
            "- Laminated Safety Glass 10mm, 2,600 sq ft\n"
            "- Custom Anodized Frame Extrusion, 950 linear ft\n"
            "- Structural Silicone Sealant, 40 cartridges\n\n"
            "This is a Platinum account order, please apply standard account discount. "
            "Full spec sheet attached.\n\n"
            "Best,\nAlicia Nguyen, Sr. Estimator"
        ),
        "attachments": ["email_003_specsheet.txt"],
        "label": "rfq_attachment",
    },
    {
        "id": "email_004",
        "from": "ops@prairiewd.example",
        "to": "quotes@obe-sales.example",
        "subject": "Following up on invoice #48213",
        "date": "2026-08-04T13:20:00-05:00",
        "body": (
            "Hi, just checking on the status of invoice #48213 from last month, "
            "we haven't seen payment confirmation come through on our end. Can someone confirm?\n\nThanks,\nMark"
        ),
        "attachments": [],
        "label": "not_rfq",
    },
    {
        "id": "email_005",
        "from": "newsletter@glassindustrytoday.example",
        "to": "quotes@obe-sales.example",
        "subject": "5 Trends Shaping Facade Design in 2026",
        "date": "2026-08-04T16:00:00-05:00",
        "body": "This week's roundup: sustainable glazing, low-carbon aluminum, and more. Read the full article on our site.",
        "attachments": [],
        "label": "not_rfq",
    },
    {
        "id": "email_006",
        "from": "purchasing@coastalenvelope.example",
        "to": "quotes@obe-sales.example",
        "subject": "Urgent RFQ - Low-E glass restock",
        "date": "2026-08-05T07:30:00-04:00",
        "body": (
            "Team,\n\n"
            "Need an urgent quote — running low on stock for an active install:\n"
            "- Low-E Coated Glass 6mm: 1,100 sq ft\n"
            "- Heavy Duty Hinge Set: 60 each\n\n"
            "Can you confirm lead time? We may need expedited shipping.\n\n"
            "Priya Subramaniam\nCoastal Envelope Solutions"
        ),
        "attachments": [],
        "label": "rfq_inline",
    },
    {
        "id": "email_007",
        "from": "procurement@meridianglazing.example",
        "to": "quotes@obe-sales.example",
        "subject": "RE: RFQ - Clear glass + standard frame for Riverside project",
        "date": "2026-08-05T10:05:00-05:00",
        "body": (
            "Quick addition to yesterday's request — please also include:\n"
            "- Tempered Glass 8mm: 600 sq ft (for the entry doors)\n\n"
            "Everything else stays the same as before.\n\nDana"
        ),
        "attachments": [],
        "label": "rfq_followup",
    },
    {
        "id": "email_008",
        "from": "buyer@unioncurtainwall.example",
        "to": "quotes@obe-sales.example",
        "subject": "Are you still able to support Net 30 terms?",
        "date": "2026-08-05T14:40:00-05:00",
        "body": "Before we finalize, can you confirm Net 30 payment terms are still available on our account? Thanks.",
        "attachments": [],
        "label": "not_rfq",
    },
    {
        "id": "email_009",
        "from": "estimating@harborlinefacade.example",
        "to": "quotes@obe-sales.example",
        "subject": "RFQ - small ancillary order, Pier 14",
        "date": "2026-08-06T09:00:00-04:00",
        "body": (
            "Separate small item for the same project, please quote standalone:\n"
            "- EPDM Gasket Strip: 300 linear ft\n"
            "- Structural Silicone Sealant: 10 cartridges\n\nThanks,\nAlicia"
        ),
        "attachments": [],
        "label": "rfq_inline",
    },
    {
        "id": "email_010",
        "from": "ap@prairiewd.example",
        "to": "quotes@obe-sales.example",
        "subject": "RFQ - Bronze tier trial order",
        "date": "2026-08-06T15:22:00-05:00",
        "body": (
            "We'd like to place a trial order to evaluate your pricing:\n"
            "- Standard Aluminum Frame Extrusion: 200 linear ft\n"
            "- Clear Float Glass 6mm: 500 sq ft\n\n"
            "No account discount expected, just standard Bronze tier pricing.\n\nMark, Prairie Window & Door"
        ),
        "attachments": [],
        "label": "rfq_inline",
    },
]

for e in emails:
    with open(f"{BASE}/emails/{e['id']}.json", "w") as f:
        json.dump(e, f, indent=2)

# ---------------------------------------------------------------------------
# 4. Attachment text files referenced above
# ---------------------------------------------------------------------------

linesheet_002 = """LAKESIDE COMMONS - CURTAINWALL BID
Line Sheet - Union Curtainwall Systems
Prepared: 2026-08-02

ITEM                                   QTY      UNIT
--------------------------------------------------------
Clear Float Glass 6mm                  3,100    sq ft
Thermally Broken Aluminum Frame        1,400    linear ft
EPDM Gasket Strip                      1,400    linear ft
Structural Silicone Sealant            55       cartridge

Notes:
- Need pricing broken out by line item, not just total
- Preferred lead time under 14 days for all items
- Comparing against one other supplier, decision expected within 5 business days
"""

specsheet_003 = """PIER 14 REDEVELOPMENT - PHASE 1 SPEC SHEET
Harborline Facade Co.
Prepared by: Alicia Nguyen, Sr. Estimator
Date: 2026-08-03

MATERIALS REQUIRED:
1. Laminated Safety Glass 10mm ................ 2,600 sq ft
2. Custom Anodized Frame Extrusion ............ 950 linear ft
3. Structural Silicone Sealant ................ 40 cartridge

ACCOUNT: ACC-1003 (Platinum Tier)
PAYMENT TERMS ON FILE: Net 45
DELIVERY: Pier 14 Staging Yard, East Region
REQUIRED ON SITE BY: 2026-09-15

Please apply standard Platinum account discount per our master agreement.
"""

with open(f"{BASE}/attachments/email_002_linesheet.txt", "w") as f:
    f.write(linesheet_002)

with open(f"{BASE}/attachments/email_003_specsheet.txt", "w") as f:
    f.write(specsheet_003)

# ---------------------------------------------------------------------------
# 5. README describing the dataset + intended agent workflow
# ---------------------------------------------------------------------------

readme = """# RFQ Email -> Quote Generator: Demo Dataset

Synthetic dataset for demoing a Claude Code agentic workflow that reads an
inbox, identifies RFQs, extracts line items, prices them, and drafts a quote.
All companies, domains, and people are fictional.

## Files

- `emails/email_00X.json` - 10 inbox messages. Each has:
  `id, from, to, subject, date, body, attachments, label`
  `label` is a demo-only ground-truth tag (not something the agent should read):
    - `rfq_inline`    - RFQ with line items in the email body
    - `rfq_attachment`- RFQ referencing an attached line sheet / spec sheet
    - `rfq_followup`  - amends a previous RFQ (tests thread/context handling)
    - `not_rfq`       - noise: invoice follow-up, newsletter, terms question
- `attachments/*.txt` - itemized line sheets / spec sheets referenced by some emails
- `pricing_catalog.json` - SKU, unit price, unit of measure, lead time, stock qty
- `customers.json` - account tier, discount %, payment terms, region, keyed by domain

## Suggested agent pipeline

1. **Classify** each email: RFQ vs not (use `label` only to check your agent's
   accuracy afterward, never as input to the agent).
2. **Extract line items** from body text and/or attachment (product name, qty, unit).
3. **Match customer**: sender domain -> `customers.json` -> account tier/discount/terms.
4. **Price**: match extracted product names to `pricing_catalog.json` SKUs
   (fuzzy match needed - emails use natural names, not SKU codes), apply
   account discount, sum lead times to the longest-lead item.
5. **Draft quote**: structured output (JSON or a formatted quote email) with
   line items, unit price, discount applied, total, and estimated delivery date.

## Things this dataset is designed to stress-test

- `email_007` is a follow-up to `email_001` - agent should recognize thread
  continuity (same customer/project, additive line item) rather than treat
  it as an unrelated new RFQ.
- `email_002` and `email_003` require reading the attachment, not just the body.
- `email_004`, `email_005`, `email_008` are deliberately NOT RFQs - a good
  classifier should skip these rather than trying to generate quotes from them.
- `email_010` is a Bronze-tier account with 0% discount - checks that the
  agent doesn't apply a discount by default.
- Product names in emails ("Clear glass", "Low-E glass") don't always match
  catalog names exactly - tests fuzzy SKU matching.
"""

with open(f"{BASE}/README.md", "w") as f:
    f.write(readme)

print("Done. Generated:")
for root, _, files in os.walk(BASE):
    for fn in sorted(files):
        print(os.path.join(root, fn))
